#include <stdio.h>
#include <stdlib.h>

int main()
{
 FILE* archivo;

 char mensaje[50];

archivo = fopen("datos.csv","r");

while (!feof(archivo))
{
fgets(mensaje,49,archivo);
printf("%s", mensaje);
}




fclose(archivo);



    return 0;
}
