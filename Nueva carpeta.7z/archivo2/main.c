#include <stdio.h>
#include <stdlib.h>

int main()
{
 FILE* archivo;

 char mensaje[50];
 char id[10] = "1";
 char nombre[50] = "juan";
 char apellido[50] = "Perez";

archivo = fopen("datos.csv","r");

fscanf(archivo,"%[^,],%[^,],%[^\n]\n",id,nombre,apellido);

printf("%s--%s--%s--\n",id,nombre,apellido);

/*while (!feof(archivo))
{
fgets(mensaje,49,archivo);
printf("%s", mensaje);
}*/




fclose(archivo);



    return 0;
}
